# modules/usecases.py
import streamlit as st
import pandas as pd

def get_use_cases(role):
    # Mock data - replace with real implementation
    return [
        {"id": 1, "description": "Jenkins integration issue", "status": "Open"},
        {"id": 2, "description": "Ansible timeout problem", "status": "Resolved"}
    ]

def show(role):
    st.header("XLR Adoption Challenges")
    cases = get_use_cases(role)
    for case in cases:
        st.write(f"Case {case['id']}: {case['description']} ({case['status']})")