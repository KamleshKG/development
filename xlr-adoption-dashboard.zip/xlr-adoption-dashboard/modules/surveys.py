# modules/surveys.py
import streamlit as st
import sqlite3
from datetime import datetime


def save_pre_survey(participant_id, familiarity, challenges):
    """Save pre-training survey data to database"""
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()
    c.execute("INSERT INTO pre_surveys (participant_id, xlr_familiarity, challenges, timestamp) VALUES (?, ?, ?, ?)",
              (participant_id, familiarity, challenges, datetime.now()))
    conn.commit()
    conn.close()


def save_post_survey(participant_id, content_rating, presenter_rating, goals_clear, feedback):
    """Save post-training survey data to database"""
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()
    c.execute(
        "INSERT INTO post_surveys (participant_id, content_rating, presenter_rating, goals_clear, feedback, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
        (participant_id, content_rating, presenter_rating, int(goals_clear), feedback, datetime.now()))
    conn.commit()
    conn.close()


def get_participant_id(role, project_id):
    """Get or create participant ID"""
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()

    # Check if participant exists
    c.execute("SELECT id FROM participants WHERE role=? AND project_id=?", (role, project_id))
    result = c.fetchone()

    if not result:
        # Create new participant
        c.execute("INSERT INTO participants (role, project_id) VALUES (?, ?)", (role, project_id))
        participant_id = c.lastrowid
    else:
        participant_id = result[0]

    conn.commit()
    conn.close()
    return participant_id


def show(role):
    st.header(f"{role} Surveys")

    # Get project ID (simplified for demo)
    project_id = st.text_input("Enter your Project ID")

    if not project_id:
        st.warning("Please enter a Project ID to continue")
        return

    participant_id = get_participant_id(role, project_id)

    tab1, tab2 = st.tabs(["Pre-Training Survey", "Post-Training Survey"])

    with tab1:
        with st.form("pre_survey_form"):
            st.subheader("Pre-Training Assessment")
            familiarity = st.slider("How familiar are you with XLR? (1-5)", 1, 5, 3)
            challenges = st.text_area("What are your biggest release challenges?")

            if st.form_submit_button("Submit Pre-Training Survey"):
                save_pre_survey(participant_id, familiarity, challenges)
                st.success("Pre-training survey submitted successfully!")

    with tab2:
        with st.form("post_survey_form"):
            st.subheader("Post-Training Evaluation")
            content_rating = st.slider("Content quality rating (1-5)", 1, 5, 3)
            presenter_rating = st.slider("Presenter effectiveness (1-5)", 1, 5, 3)
            goals_clear = st.checkbox("The training goals were clear")
            feedback = st.text_area("Additional feedback")

            if st.form_submit_button("Submit Post-Training Survey"):
                save_post_survey(participant_id, content_rating, presenter_rating, goals_clear, feedback)
                st.success("Post-training survey submitted successfully!")