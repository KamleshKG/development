import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3


def show(role=None):
    conn = sqlite3.connect('database/xlr_adoption.db')

    st.header("Performance Analytics")

    # Throughput Trends
    throughput = pd.read_sql(f"""
    SELECT 
        strftime('%Y-%W', resolved_date) as week,
        COUNT(*) as stories_completed,
        SUM(story_points) as points_delivered
    FROM jira_stories
    WHERE status = 'Done'
    {'AND participant_id IN (SELECT id FROM participants WHERE role = ?)' if role else ''}
    GROUP BY week
    ORDER BY week
    """, conn, params=(role,) if role else ())

    if not throughput.empty:
        fig = px.line(throughput, x='week', y=['stories_completed', 'points_delivered'],
                      title="Weekly Throughput")
        st.plotly_chart(fig)

    # WIP Analysis
    wip = pd.read_sql("""
    SELECT 
        p.role,
        COUNT(CASE WHEN j.status NOT IN ('Done', 'Backlog') THEN 1 END) as active_wip
    FROM jira_stories j
    JOIN participants p ON j.participant_id = p.id
    GROUP BY p.role
    """, conn)

    if not wip.empty:
        fig = px.bar(wip, x='role', y='active_wip', title="Work in Progress by Role")
        st.plotly_chart(fig)

    # XLR Performance Correlation
    perf = pd.read_sql("""
    SELECT 
        j.xlr_integrated,
        AVG(j.story_points) as avg_points,
        AVG(JULIANDAY(j.resolved_date) - JULIANDAY(j.created_date)) as avg_cycle_time
    FROM jira_stories j
    WHERE j.status = 'Done'
    GROUP BY j.xlr_integrated
    """, conn)

    if not perf.empty:
        fig = px.scatter(perf, x='avg_cycle_time', y='avg_points',
                         color='xlr_integrated', size=[10, 10],
                         title="Cycle Time vs Story Points")
        st.plotly_chart(fig)

    conn.close()
