# modules/vsm.py
import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3


def calculate_flow_efficiency(conn):
    """Calculate % time spent in active work vs waiting"""
    return pd.read_sql("""
    SELECT 
        (SUM(CASE WHEN status IN ('In Progress', 'In Review') THEN 1 ELSE 0 END) * 100.0 / 
        COUNT(*)) as flow_efficiency
    FROM jira_stories
    WHERE status != 'Backlog'
    """, conn)


def show(role=None):
    conn = sqlite3.connect('database/xlr_adoption.db')

    st.header("Value Stream Metrics")

    # 1. Flow Efficiency
    flow_eff = calculate_flow_efficiency(conn).iloc[0]['flow_efficiency']
    st.metric("Flow Efficiency", f"{flow_eff:.1f}%",
              delta="+5.2% vs last quarter" if flow_eff > 30 else "-2.1% vs target")

    # 2. State Transition Times
    state_times = pd.read_sql(f"""
    SELECT 
        status,
        AVG(JULIANDAY(resolved_date) - JULIANDAY(created_date)) as avg_days
    FROM jira_stories
    WHERE status != 'Backlog'
    {'AND participant_id IN (SELECT id FROM participants WHERE role = ?)' if role else ''}
    GROUP BY status
    """, conn, params=(role,) if role else ())

    if not state_times.empty:
        fig = px.bar(state_times, x='status', y='avg_days',
                     title="Average Time in Each State")
        st.plotly_chart(fig)

    # 3. Cumulative Flow Diagram
    flow_daily = pd.read_sql("""
    SELECT 
        date(created_date) as day,
        status,
        COUNT(*) as count
    FROM jira_stories
    GROUP BY day, status
    ORDER BY day
    """, conn)

    if not flow_daily.empty:
        fig = px.area(flow_daily, x='day', y='count', color='status',
                      title="Work Item Distribution Over Time")
        st.plotly_chart(fig)

    conn.close()