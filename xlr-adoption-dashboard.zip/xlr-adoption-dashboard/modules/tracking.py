import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3
from datetime import datetime, timedelta
import random


def generate_demo_tracking_data():
    """Generate realistic SRE tracking data"""
    return pd.DataFrame({
        'release_id': [f'REL-2023-{i:03d}' for i in range(1, 31)],
        'status': random.choices(
            ['Planned', 'In Progress', 'Deployed', 'Rolled Back', 'Verified'],
            weights=[10, 30, 40, 15, 5], k=30),
        'environment': ['Prod'] * 10 + ['Stage'] * 8 + ['Test'] * 7 + ['Dev'] * 5,
        'start_time': [datetime.now() - timedelta(days=random.randint(0, 30)) for _ in range(30)],
        'duration_min': [random.randint(5, 180) for _ in range(30)],
        'success': [random.random() > 0.2 for _ in range(30)],
        'xlr_version': [random.choice(['1.0', '1.1', '2.0', None]) for _ in range(30)]
    })


def show(role):
    st.header(f"Release Tracking Dashboard - {role}")

    # Demo data - replace with real DB queries
    df = generate_demo_tracking_data()

    # Key Metrics
    col1, col2, col3 = st.columns(3)
    col1.metric("Releases This Month", len(df), "12% ↑")
    col2.metric("Success Rate",
                f"{df['success'].mean() * 100:.1f}%",
                "+5.2% vs last month")
    col3.metric("Avg Duration",
                f"{df['duration_min'].mean():.1f} min",
                "-8.3 min improvement")

    # Visualizations
    tab1, tab2 = st.tabs(["Release Status", "XLR Adoption"])

    with tab1:
        fig1 = px.pie(df, names='status',
                      title="Release Status Distribution")
        st.plotly_chart(fig1, use_container_width=True)

        fig2 = px.histogram(df, x='duration_min', color='success',
                            title="Deployment Duration vs Success")
        st.plotly_chart(fig2, use_container_width=True)

    with tab2:
        xlr_df = df[df['xlr_version'].notnull()]
        if not xlr_df.empty:
            fig3 = px.box(xlr_df, x='xlr_version', y='duration_min',
                          title="XLR Version Performance")
            st.plotly_chart(fig3, use_container_width=True)
        else:
            st.warning("No XLR-tracked releases found")

    # Raw Data
    with st.expander("View Raw Data"):
        st.dataframe(df.sort_values('start_time', ascending=False))