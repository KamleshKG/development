import streamlit as st
import pandas as pd
import plotly.express as px


def get_training_content():
    """Return structured training curriculum"""
    return {
        "Getting Started": [
            ("Introduction to XLR", "video", "15 min"),
            ("Key Concepts", "text", "10 min"),
            ("Installation Guide", "hands-on", "30 min")
        ],
        "Core Features": [
            ("Pipeline Orchestration", "video", "22 min"),
            ("Risk Prediction", "hands-on", "45 min"),
            ("Integration with Jenkins", "lab", "60 min")
        ],
        "Advanced Topics": [
            ("Custom Templates", "video", "18 min"),
            ("DB Deployments with Datical", "lab", "50 min"),
            ("Troubleshooting", "text", "25 min")
        ]
    }


def show(role):
    st.header(f"XLR Training Portal - {role}")

    # Role-specific learning paths
    if role == "DevOps":
        st.success("**Recommended Learning Path:** Pipeline Automation → Integration → Advanced Templating")
    elif role == "SRE":
        st.info("**Recommended Learning Path:** Risk Prediction → Monitoring → Troubleshooting")

    # Training Modules
    content = get_training_content()
    for section, items in content.items():
        with st.expander(f"📚 {section}"):
            for title, format_, duration in items:
                cols = st.columns([3, 1, 1])
                cols[0].write(f"**{title}**")
                cols[1].markdown(f"`{format_}`")
                cols[2].markdown(f"⏱️ {duration}")

                # Add completion checkbox
                key = f"{section}_{title}_completed"
                if st.checkbox("Mark as completed", key=key):
                    st.session_state[key] = True

    # Progress Tracking
    st.subheader("Your Progress")
    total_items = sum(len(items) for items in content.values())
    completed = sum(1 for key in st.session_state if key.endswith("_completed"))
    progress = completed / total_items

    st.progress(progress)
    st.metric("Completion Rate", f"{progress * 100:.1f}%",
              delta=f"+{completed} modules" if completed > 0 else "Get started!")

    # Recommended Resources
    st.subheader("Role-Specific Resources")
    if role == "DevOps":
        st.video("https://youtu.be/dQw4w9WgXcQ")  # Replace with actual XLR tutorial
        st.download_button("Download Cheat Sheet",
                           data=open("assets/xlr_cheatsheet.pdf", "rb").read(),
                           file_name="xlr_cheatsheet.pdf")