# modules/reporting.py
import streamlit as st
import pandas as pd
import plotly.express as px
import sqlite3
from datetime import datetime, timedelta


def get_survey_data(role=None):
    """Retrieve survey data with optional role filtering"""
    conn = sqlite3.connect('database/xlr_adoption.db')

    base_query = """
        SELECT 
            p.role, 
            COALESCE(ps.xlr_familiarity, (pst.content_rating + pst.presenter_rating)/2.0) as rating,
            COALESCE(ps.timestamp, pst.timestamp) as timestamp,
            CASE 
                WHEN ps.xlr_familiarity IS NOT NULL THEN 'Pre-Training' 
                ELSE 'Post-Training' 
            END as survey_type
        FROM participants p
        LEFT JOIN pre_surveys ps ON p.id = ps.participant_id
        LEFT JOIN post_surveys pst ON p.id = pst.participant_id
        WHERE 1=1
    """

    if role:
        base_query += f" AND p.role = '{role}'"

    df = pd.read_sql(base_query, conn)
    conn.close()

    if not df.empty:
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df['week'] = df['timestamp'].dt.strftime('%Y-%U')
    return df


def get_adoption_metrics(role=None):
    """Get metrics filtered by role if specified"""
    # Mock data - replace with real queries
    roles = [role] if role else ['DevOps', 'SRE', 'LOB', 'FL', 'SM']
    metrics = pd.DataFrame([{
        'role': r,
        'pipelines_migrated': min(25, 5 + i * 5),
        'success_rate': 70 + i * 5,
        'avg_deployment_time': max(1.0, 2.5 - i * 0.3),
        'failed_deployments': max(1, 5 - i)
    } for i, r in enumerate(roles)])

    return metrics


def show(role):
    st.header(f"XLR Adoption Reports - {role}" if role else "XLR Adoption Reports")

    # Three-tab layout as requested
    tab1, tab2, tab3 = st.tabs(["Training Feedback", "Adoption Metrics", "Raw Data"])

    with tab1:
        st.subheader(f"Training Feedback for {role}" if role else "All Training Feedback")
        df = get_survey_data(role)

        if not df.empty:
            col1, col2 = st.columns([2, 1])

            with col1:
                fig1 = px.line(df, x='timestamp', y='rating', color='survey_type',
                               title="Rating Trend Over Time")
                st.plotly_chart(fig1, use_container_width=True)

                fig2 = px.box(df, x='role', y='rating', color='survey_type',
                              title="Rating Distribution")
                st.plotly_chart(fig2, use_container_width=True)

            with col2:
                fig3 = px.pie(df, names='survey_type',
                              title="Survey Type Distribution")
                st.plotly_chart(fig3, use_container_width=True)

                avg_rating = df['rating'].mean()
                st.metric("Average Rating", f"{avg_rating:.1f}/5",
                          delta=f"{(avg_rating - 3):+.1f} vs baseline")
        else:
            st.warning("No survey data available yet")

    with tab2:
        st.subheader(f"Adoption Metrics for {role}" if role else "All Adoption Metrics")
        metrics = get_adoption_metrics(role)

        # Top Metrics Row
        col1, col2, col3 = st.columns(3)
        col1.metric("Pipelines Migrated",
                    f"{metrics['pipelines_migrated'].sum() if not role else metrics['pipelines_migrated'].iloc[0]}/25",
                    "12 this week" if not role else "3 this week")
        col2.metric("Success Rate",
                    f"{metrics['success_rate'].mean() if not role else metrics['success_rate'].iloc[0]:.1f}%",
                    "+5.2% vs last month")
        col3.metric("Deployment Time",
                    f"{metrics['avg_deployment_time'].mean() if not role else metrics['avg_deployment_time'].iloc[0]:.1f} hrs",
                    "-0.8h improvement")

        # Visualizations Row
        fig4 = px.bar(metrics, x='role' if not role else None, y='pipelines_migrated',
                      title="Pipelines Migrated" + ("" if not role else f" ({role})"))
        st.plotly_chart(fig4, use_container_width=True)

        fig5 = px.scatter(metrics, x='avg_deployment_time', y='success_rate',
                          size='pipelines_migrated', color=None if role else 'role',
                          title="Efficiency vs Success Rate")
        st.plotly_chart(fig5, use_container_width=True)

    with tab3:
        st.subheader("Raw Data Export")

        st.markdown("### Survey Data")
        survey_df = get_survey_data(role)
        st.dataframe(survey_df if not survey_df.empty else pd.DataFrame())

        st.download_button(
            label="Download Survey Data as CSV",
            data=survey_df.to_csv(index=False).encode('utf-8'),
            file_name=f"xlr_survey_data_{role.lower() if role else 'all'}.csv",
            mime='text/csv'
        )

        st.markdown("### Adoption Metrics")
        metrics_df = get_adoption_metrics(role)
        st.dataframe(metrics_df)

        st.download_button(
            label="Download Metrics as CSV",
            data=metrics_df.to_csv(index=False).encode('utf-8'),
            file_name=f"xlr_metrics_{role.lower() if role else 'all'}.csv",
            mime='text/csv'
        )