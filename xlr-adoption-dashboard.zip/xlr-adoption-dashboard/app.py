# app.py
import streamlit as st
from modules import training, surveys, tracking, usecases, reporting , vsm , analytics
import database.init_db
from modules import analytics

# Initialize DB
try:
    database.init_db.init_db()
except Exception as e:
    st.warning(f"Database initialization warning: {str(e)}")

# App Config
st.set_page_config(layout="wide", page_title="XLR Adoption Dashboard")

# Sidebar Navigation
role = st.sidebar.selectbox("Your Role", ["SRE", "SE", "DevOps", "FL", "LOB", "SM"])
# menu = st.sidebar.radio("Menu", ["Training", "Surveys", "Tracking", "Use Cases", "Reports"])

# Update menu:
menu = st.sidebar.radio("Menu", ["Training", "Surveys", "Tracking", "Use Cases", "Reports", "Value Stream", "Performance"])


# Main App Logic
try:
    if menu == "Training":
        training.show(role)
    elif menu == "Surveys":
        surveys.show(role)
    elif menu == "Tracking":
        tracking.show(role)
    elif menu == "Use Cases":
        usecases.show(role)
    elif menu == "Reports":
        reporting.show(role)
        # Add new menu handlers
    elif menu == "Value Stream":
        vsm.show(role)
    elif menu == "Performance":
        analytics.show(role)
except Exception as e:
    st.error(f"Error loading {menu} module: {str(e)}")
    st.info("Please check the module implementation")