# database/init_db.py
import sqlite3
from datetime import datetime


def init_db():
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()

    # Enable foreign key constraints
    c.execute("PRAGMA foreign_keys = ON")

    # Enhanced Participants Table
    c.execute('''CREATE TABLE IF NOT EXISTS participants
                 (id INTEGER PRIMARY KEY,
                 email TEXT UNIQUE,
                 name TEXT,
                 role TEXT CHECK(role IN ('DevOps', 'SRE', 'LOB', 'FL', 'SM')),
                 team TEXT,
                 employee_id TEXT,
                 project_id TEXT,
                 onboard_date DATE,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # Survey Tables (unchanged)
    c.execute('''CREATE TABLE IF NOT EXISTS pre_surveys
                 (id INTEGER PRIMARY KEY,
                 participant_id INTEGER,
                 xlr_familiarity INTEGER CHECK(xlr_familiarity BETWEEN 1 AND 5),
                 challenges TEXT,
                 timestamp TIMESTAMP,
                 FOREIGN KEY(participant_id) REFERENCES participants(id))''')

    c.execute('''CREATE TABLE IF NOT EXISTS post_surveys
                 (id INTEGER PRIMARY KEY,
                 participant_id INTEGER,
                 content_rating INTEGER CHECK(content_rating BETWEEN 1 AND 5),
                 presenter_rating INTEGER CHECK(presenter_rating BETWEEN 1 AND 5),
                 goals_clear BOOLEAN,
                 feedback TEXT,
                 timestamp TIMESTAMP,
                 FOREIGN KEY(participant_id) REFERENCES participants(id))''')

    # Enhanced Jira Stories Table
    c.execute('''CREATE TABLE IF NOT EXISTS jira_stories
                 (id TEXT PRIMARY KEY,
                 participant_id INTEGER,
                 title TEXT,
                 description TEXT,
                 status TEXT CHECK(status IN ('Backlog', 'Selected', 'In Progress', 
                                           'In Review', 'Done', 'Blocked')),
                 type TEXT CHECK(type IN ('Feature', 'Bug', 'Improvement', 'Technical Debt')),
                 component TEXT,
                 priority INTEGER CHECK(priority BETWEEN 1 AND 5),
                 story_points INTEGER,
                 business_value TEXT,
                 xlr_integrated BOOLEAN,
                 xlr_version TEXT,
                 created_date TIMESTAMP,
                 resolved_date TIMESTAMP,
                 cycle_time_days INTEGER,
                 FOREIGN KEY(participant_id) REFERENCES participants(id))''')

    # Sprint Planning Table
    c.execute('''CREATE TABLE IF NOT EXISTS sprint_plans
                 (id INTEGER PRIMARY KEY,
                 sprint_number INTEGER,
                 name TEXT,
                 start_date DATE,
                 end_date DATE,
                 story_id TEXT,
                 planned_capacity INTEGER,
                 actual_capacity INTEGER,
                 outcome TEXT,
                 FOREIGN KEY(story_id) REFERENCES jira_stories(id))''')

      # In init_db() function:
    c.execute("""
    CREATE VIEW IF NOT EXISTS vsm_metrics AS
    SELECT 
        type,
        AVG(JULIANDAY(resolved_date) - JULIANDAY(created_date)) as avg_lead_time,
        COUNT(*) as count
    FROM jira_stories
    WHERE status = 'Done'
    GROUP BY type
    """)

    c.execute("""
    CREATE VIEW IF NOT EXISTS performance_metrics AS
    SELECT 
        strftime('%Y-%W', resolved_date) as week,
        COUNT(*) as throughput,
        AVG(story_points) as avg_points
    FROM jira_stories
    WHERE status = 'Done'
    GROUP BY week
    """)

    # Story Dependencies
    c.execute('''CREATE TABLE IF NOT EXISTS story_dependencies
                 (id INTEGER PRIMARY KEY,
                 blocking_story_id TEXT,
                 blocked_story_id TEXT,
                 dependency_type TEXT CHECK(dependency_type IN ('Finish-to-Start', 'Start-to-Start')),
                 FOREIGN KEY(blocking_story_id) REFERENCES jira_stories(id),
                 FOREIGN KEY(blocked_story_id) REFERENCES jira_stories(id))''')

    # XLR Deployment Logs
    c.execute('''CREATE TABLE IF NOT EXISTS xlr_deployments
                 (id INTEGER PRIMARY KEY,
                 jira_id TEXT,
                 environment TEXT CHECK(environment IN ('DEV', 'TEST', 'STAGE', 'PROD')),
                 status TEXT CHECK(status IN ('Pending', 'Success', 'Failed', 'Rollback')),
                 start_time TIMESTAMP,
                 end_time TIMESTAMP,
                 duration_seconds INTEGER,
                 triggered_by INTEGER,
                 FOREIGN KEY(jira_id) REFERENCES jira_stories(id),
                 FOREIGN KEY(triggered_by) REFERENCES participants(id))''')
    # Add these tables to init_db()
    c.execute('''CREATE TABLE IF NOT EXISTS training_progress
                 (id INTEGER PRIMARY KEY,
                 participant_id INTEGER,
                 module_name TEXT,
                 completed BOOLEAN,
                 completion_date TIMESTAMP,
                 FOREIGN KEY(participant_id) REFERENCES participants(id))''')

    c.execute('''CREATE TABLE IF NOT EXISTS release_tracking
                 (id INTEGER PRIMARY KEY,
                 release_id TEXT UNIQUE,
                 status TEXT,
                 environment TEXT,
                 start_time TIMESTAMP,
                 end_time TIMESTAMP,
                 xlr_version TEXT,
                 success BOOLEAN)''')




    # Create indexes for performance
    c.execute("CREATE INDEX IF NOT EXISTS idx_jira_status ON jira_stories(status)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_jira_type ON jira_stories(type)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_participant_role ON participants(role)")

    # Insert baseline reference data
    try:
        # Add sample XL Release versions
        versions = [('1.0',), ('1.1',), ('2.0',)]
        c.executemany("INSERT OR IGNORE INTO xlr_versions (version) VALUES (?)", versions)

        # Add sample components
        components = [('API',), ('UI',), ('Database',), ('Integration',), ('Security',)]
        c.executemany("INSERT OR IGNORE INTO components (name) VALUES (?)", components)

        conn.commit()
    except sqlite3.OperationalError:
        pass  # Tables may not exist yet

    conn.close()


def populate_demo_data():
    """Helper function to generate sample data during development"""
    from faker import Faker
    import random
    from datetime import datetime, timedelta

    fake = Faker()
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()

    # Clear existing data (optional)
    if input("Clear existing data? (y/n): ").lower() == 'y':
        c.executescript("""
        DELETE FROM xlr_deployments;
        DELETE FROM story_dependencies;
        DELETE FROM sprint_plans;
        DELETE FROM jira_stories;
        DELETE FROM post_surveys;
        DELETE FROM pre_surveys;
        DELETE FROM participants;
        """)

    # Generate Participants
    roles = ['DevOps', 'SRE', 'LOB', 'FL', 'SM']
    teams = ['Alpha', 'Bravo', 'Charlie']
    participants = []
    for _ in range(50):
        participants.append((
            fake.email(),
            fake.name(),
            random.choice(roles),
            random.choice(teams),
            f"EMP{fake.random_number(digits=4)}",
            f"PROJ-{random.randint(1, 10)}",
            (datetime.now() - timedelta(days=random.randint(30, 365))).date()
        ))
    c.executemany("""
    INSERT INTO participants (email, name, role, team, employee_id, project_id, onboard_date)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, participants)

    # Generate Jira Stories
    statuses = ['Backlog', 'Selected', 'In Progress', 'In Review', 'Done']
    types = ['Feature', 'Bug', 'Improvement', 'Technical Debt']
    stories = []
    for i in range(1, 151):
        stories.append((
            f"PROJ-{i}",
            random.randint(1, 50),
            f"{types[i % 4]}: {fake.catch_phrase()}",
            fake.text(),
            random.choice(statuses),
            types[i % 4],
            random.choice(['API', 'UI', 'Database', 'Integration', 'Security']),
            random.randint(1, 5),
            random.randint(1, 8),
            random.choice(['High', 'Medium', 'Low']),
            random.random() > 0.3,  # xlr_integrated
            random.choice(['1.0', '1.1', '2.0']) if random.random() > 0.3 else None,
            (datetime.now() - timedelta(days=random.randint(1, 90))).isoformat(),
            (datetime.now() - timedelta(days=random.randint(0, 30))).isoformat() if random.random() > 0.7 else None,
            random.randint(1, 14)
        ))
    c.executemany("""
    INSERT INTO jira_stories VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
    """, stories)

    conn.commit()
    conn.close()
    print("Demo data populated successfully")


if __name__ == "__main__":
    init_db()
    if input("Populate with demo data? (y/n): ").lower() == 'y':
        populate_demo_data()