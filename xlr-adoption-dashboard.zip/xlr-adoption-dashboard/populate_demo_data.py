# populate_demo_data.py
import sqlite3
import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()

# Configuration
NUM_PARTICIPANTS = 50
NUM_JIRA_STORIES = 150
NUM_SPRINTS = 8
ROLES = ['DevOps', 'SRE', 'LOB', 'FL', 'SM']
TEAMS = ['Team A', 'Team B', 'Team C']
XL_RELEASE_VERSIONS = ['1.0', '1.1', '1.2', '2.0']


def generate_demo_data():
    conn = sqlite3.connect('database/xlr_adoption.db')
    c = conn.cursor()

    # Clear existing data
    c.executescript("""
    DELETE FROM story_dependencies;
    DELETE FROM sprint_plans;
    DELETE FROM jira_stories;
    DELETE FROM participants;
    """)

    # Create sprint timeline
    sprint_dates = [
        (datetime.now() - timedelta(days=7 * (NUM_SPRINTS - i))).date()
        for i in range(NUM_SPRINTS)
    ]

    # Generate Participants with realistic role distribution
    participants = []
    role_weights = [0.35, 0.25, 0.15, 0.15, 0.10]  # DevOps most common
    for i in range(1, NUM_PARTICIPANTS + 1):
        role = random.choices(ROLES, weights=role_weights)[0]
        participants.append((
            fake.email(),
            role,
            random.choice(TEAMS),
            f"EMP{fake.random_number(digits=4)}",
            datetime.now() - timedelta(days=random.randint(30, 365))
        ))
    c.executemany("""
    INSERT INTO participants (email, role, team, employee_id, onboard_date)
    VALUES (?, ?, ?, ?, ?)
    """, participants)

    # Generate realistic Jira stories with value chain
    story_types = ['Feature', 'Bug', 'Improvement', 'Technical Debt']
    components = ['API', 'UI', 'Database', 'Integration', 'Security']
    status_flow = ['Backlog', 'Selected', 'In Progress', 'In Review', 'Done']

    jira_stories = []
    sprint_plans = []
    story_deps = []

    for sprint_idx in range(NUM_SPRINTS):
        sprint_start = sprint_dates[sprint_idx]
        sprint_end = sprint_start + timedelta(days=14)

        # Create 15-25 stories per sprint
        stories_in_sprint = random.randint(15, 25)
        for i in range(stories_in_sprint):
            story_id = f"PROJ-{sprint_idx + 1}-{i + 1}"
            participant_id = random.randint(1, NUM_PARTICIPANTS)

            # Get participant role to influence story properties
            c.execute("SELECT role FROM participants WHERE id = ?", (participant_id,))
            creator_role = c.fetchone()[0]

            # Role-specific story patterns
            if creator_role == 'DevOps':
                story_type = random.choice(['Improvement', 'Technical Debt'])
                component = random.choice(['Integration', 'Security'])
            elif creator_role == 'SRE':
                story_type = 'Bug'
                component = random.choice(['API', 'Database'])
            else:
                story_type = 'Feature'
                component = 'UI' if creator_role == 'LOB' else 'API'

            # Status progression with realistic timings
            status_history = []
            current_status = 'Done' if random.random() > 0.2 else random.choice(status_flow[:-1])
            for status in status_flow[:status_flow.index(current_status) + 1]:
                status_date = sprint_start + timedelta(
                    days=random.randint(0, (sprint_end - sprint_start).days))
                status_history.append((status, status_date))

            # XLR integration flags
            xlr_integrated = current_status == 'Done' and random.random() > 0.3
            xlr_version = random.choice(XL_RELEASE_VERSIONS) if xlr_integrated else None

            jira_stories.append((
                story_id,
                participant_id,
                f"{story_type}: {fake.catch_phrase()}",
                current_status,
                story_type,
                component,
                xlr_integrated,
                xlr_version,
                status_history[0][1],  # created_date
                status_history[-1][1] if current_status == 'Done' else None,  # resolved_date
                random.randint(1, 8),  # story_points
                fake.bs()  # business_value
            ))

            # Add to sprint plan
            sprint_plans.append((
                sprint_idx + 1,
                story_id,
                random.choice(['Committed', 'Completed', 'Carryover'])
            ))

    # Insert Jira stories
    c.executemany("""
    INSERT INTO jira_stories (
        id, participant_id, title, status, type, component, 
        xlr_integrated, xlr_version, created_date, resolved_date,
        story_points, business_value
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, jira_stories)

    # Insert sprint plans
    c.executemany("""
    INSERT INTO sprint_plans (sprint_number, story_id, outcome)
    VALUES (?, ?, ?)
    """, sprint_plans)

    # Generate story dependencies
    story_ids = [story[0] for story in jira_stories]
    for _ in range(int(len(story_ids) * 0.3)):  # 30% have dependencies
        blocking, blocked = random.sample(story_ids, 2)
        story_deps.append((blocking, blocked))

    if story_deps:
        c.executemany("""
        INSERT INTO story_dependencies (blocking_story_id, blocked_story_id)
        VALUES (?, ?)
        """, story_deps)

    # Add training data
    add_training_data(conn)

    # Add release tracking data
    add_release_data(conn)

    conn.commit()
    conn.close()
    print(
        f"Generated {NUM_PARTICIPANTS} participants and {len(jira_stories)} Jira stories across {NUM_SPRINTS} sprints")


def add_training_data(conn):
    """Insert sample training records"""
    modules = [
        ("Introduction to XLR", "video"),
        ("Pipeline Orchestration", "hands-on"),
        ("Risk Prediction", "lab")
    ]
    for participant_id in range(1, NUM_PARTICIPANTS + 1):
        for module_name, format_ in modules:
            conn.execute("""
            INSERT INTO training_progress 
            (participant_id, module_name, completed, completion_date)
            VALUES (?, ?, ?, ?)
            """, (
                participant_id,
                module_name,
                random.random() > 0.3,  # 70% completion rate
                datetime.now() - timedelta(days=random.randint(0, 30))
            ))


def add_release_data(conn):
    """Insert sample release tracking data"""
    for i in range(1, 101):
        conn.execute("""
        INSERT INTO release_tracking 
        (release_id, status, environment, start_time, end_time, xlr_version, success)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            f"REL-2023-{i:03d}",
            random.choice(["Planned", "In Progress", "Deployed"]),
            random.choice(["Dev", "Test", "Stage", "Prod"]),
            datetime.now() - timedelta(days=random.randint(0, 60)),
            datetime.now() - timedelta(days=random.randint(0, 59)),
            random.choice(["1.0", "1.1", "2.0", None]),
            random.random() > 0.2  # 80% success rate
        ))


if __name__ == "__main__":
    generate_demo_data()