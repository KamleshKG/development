# VeriFactAI - Hallucination Detection System

## Setup
1. Install requirements:
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_lg