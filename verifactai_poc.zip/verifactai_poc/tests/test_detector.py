import pytest
from core.detector import HallucinationDetector

@pytest.fixture
def detector():
    return HallucinationDetector()

def test_hallucination_detection(detector):
    llm_output = "The Eiffel Tower is in Germany"
    result = detector.analyze_llm_output(llm_output)
    assert result["hallucination_score"] > 0.5
    assert "geographic_error" in result["breakdown"]