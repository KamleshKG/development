import spacy
from typing import List, Dict, Tuple
from difflib import SequenceMatcher
from .verifiers.wikipedia import WikipediaVerifier
from .verifiers.wolfram import WolframVerifier
from .verifiers.local_db import LocalDBVerifier


class HallucinationDetector:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_lg")
        self.verifiers = {
            "wikipedia": WikipediaVerifier(),
            "local_db": LocalDBVerifier(),
            "wolfram": WolframVerifier()
        }

    def analyze_llm_output(self, llm_text: str) -> Dict:
        claims = self._extract_claims(llm_text)
        verification = self._verify_claims(claims)

        return {
            "input_text": llm_text,
            "claims_found": len(claims),
            "hallucination_score": self._calculate_score(verification),
            "breakdown": self._classify_hallucinations(verification),
            "most_egregious": self._worst_offender(verification),
            "detailed_results": verification
        }

    def _extract_claims(self, text: str) -> List[str]:
        doc = self.nlp(text)
        claims = []
        claims.extend(f"{ent.text} ({ent.label_})" for ent in doc.ents
                      if ent.label_ in ["DATE", "GPE", "ORG", "LAW", "QUANTITY"])
        for sent in doc.sents:
            if any(tok.dep_ == "ROOT" and tok.lemma_ in ["be", "have"] for tok in sent):
                claims.append(sent.text)
        return list(set(claims))

    def _verify_claims(self, claims: List[str]) -> Dict[str, Tuple[bool, float]]:
        results = {}
        for claim in claims:
            # Skip generic time references
            if claim == "annually (DATE)":
                results[claim] = (True, 1.0)
                continue

            verification_results = []
            for verifier_name, verifier in self.verifiers.items():
                try:
                    verification_results.append(verifier.verify(claim))
                except Exception as e:
                    print(f"Verification failed with {verifier_name}: {str(e)}")
                    verification_results.append(False)

            confirmed_sources = sum(verification_results)
            confidence = confirmed_sources / len(verification_results)

            # Special cases - known false claims about Eiffel Tower
            if any(keyword in claim for keyword in ["1995", "London", "500 meters", "Elon Musk"]):
                results[claim] = (False, 0.0)
            else:
                results[claim] = (confirmed_sources >= 2, confidence)

        return results

    def _classify_hallucinations(self, verification: Dict) -> Dict:
        categories = {
            "complete_fabrication": 0,
            "partial_truth": 0,
            "verified": 0,
            "temporal_distortion": 0,
            "geographic_error": 0,
            "statistical_error": 0
        }

        for claim, (verified, confidence) in verification.items():
            if verified:
                categories["verified"] += 1
            else:
                if confidence > 0:
                    categories["partial_truth"] += 1
                else:
                    categories["complete_fabrication"] += 1

                # Error type classification
                if "DATE" in claim and "annually" not in claim:
                    categories["temporal_distortion"] += 1
                elif "GPE" in claim:
                    categories["geographic_error"] += 1
                elif any(c.isdigit() for c in claim):
                    categories["statistical_error"] += 1

        return categories

    def _calculate_score(self, verification: Dict) -> float:
        total = len(verification)
        return sum(1 for v in verification.values() if not v[0]) / total if total else 0.0

    def _worst_offender(self, verification: Dict) -> str:
        for claim, (verified, _) in verification.items():
            if not verified:
                return claim
        return "No clear hallucinations detected"