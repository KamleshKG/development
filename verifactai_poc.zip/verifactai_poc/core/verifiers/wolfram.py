import requests
import os
from urllib.parse import quote


class WolframVerifier:
    def __init__(self):
        self.app_id = os.getenv("WOLFRAM_API_KEY")
        self.base_url = "https://api.wolframalpha.com/v1/result"

    def verify(self, claim: str) -> bool:
        try:
            url = f"{self.base_url}?i={quote(claim)}&appid={self.app_id}"
            response = requests.get(url, timeout=10)
            return response.status_code == 200
        except:
            return False