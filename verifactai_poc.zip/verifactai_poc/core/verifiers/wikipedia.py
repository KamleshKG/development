import wikipedia

class WikipediaVerifier:
    def verify(self, claim: str) -> bool:
        try:
            query = claim.split("(")[0].strip()
            return len(wikipedia.search(query)) > 0
        except:
            return False