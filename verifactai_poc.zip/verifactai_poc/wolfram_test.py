import requests
import json
import sqlite3
from urllib.parse import quote
from datetime import datetime
import os
from functools import lru_cache


class WolframExpert:
    """
    Complete Wolfram Alpha integration with:
    - Simple and full query modes
    - Response caching
    - SQLite storage
    - Error recovery
    - Usage analytics
    """

    def __init__(self, app_id, cache_db="knowledge/wolfram_cache/cache.db"):
        self.app_id = app_id
        self.base_url = "https://api.wolframalpha.com/"
        self._init_cache_db(cache_db)

    def _init_cache_db(self, db_path):
        """Initialize SQLite cache database"""
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                query TEXT PRIMARY KEY,
                response TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)

    @lru_cache(maxsize=1000)
    def _memory_cache(self, query):
        """Memory cache with LRU strategy"""
        return self._db_cache(query)

    def _db_cache(self, query):
        """Check SQLite cache for existing results"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT response FROM cache WHERE query=?", (query,))
        if row := cursor.fetchone():
            return json.loads(row[0])
        return None

    def _store_cache(self, query, response):
        """Store results in both caches"""
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO cache VALUES (?, ?, ?)",
            (query, json.dumps(response), datetime.now())
        )
        self.conn.commit()
        self._memory_cache.cache_clear()  # Keep in sync

    def query(self, question, full=False, force_fresh=False):
        """
        Unified query interface
        :param question: Input question
        :param full: Return full structured data
        :param force_fresh: Bypass cache
        :return: Standardized response dict
        """
        if not force_fresh:
            if cached := self._memory_cache(question):
                return cached

        endpoint = "v2/query" if full else "v1/result"
        params = {
            "input" if full else "i": question,
            "appid": self.app_id,
            "output": "json" if full else None
        }

        response = requests.get(
            f"{self.base_url}{endpoint}",
            params={k: v for k, v in params.items() if v is not None},
            timeout=15
        )

        if response.status_code == 200:
            result = self._parse_response(response, full)
            self._store_cache(question, result)
            return result
        else:
            return {
                "success": False,
                "error": f"API Error {response.status_code}",
                "status": response.status_code
            }

    def _parse_response(self, response, full):
        """Parse API response into standard format"""
        if full:
            try:
                data = response.json()
                return {
                    "success": data.get("queryresult", {}).get("success", False),
                    "type": "full",
                    "data": self._extract_pods(data)
                }
            except json.JSONDecodeError:
                return {
                    "success": False,
                    "error": "Invalid JSON response"
                }
        else:
            return {
                "success": True,
                "type": "simple",
                "data": response.text.strip()
            }

    def _extract_pods(self, data):
        """Extract structured information from full response"""
        pods = []
        for pod in data.get("queryresult", {}).get("pods", []):
            current_pod = {
                "title": pod.get("title", ""),
                "subpods": []
            }
            for subpod in pod.get("subpods", []):
                current_pod["subpods"].append({
                    "title": subpod.get("title", ""),
                    "text": subpod.get("plaintext", "")
                })
            pods.append(current_pod)
        return pods

    def verify_fact(self, claim):
        """
        Fact verification specific method
        :param claim: Factual statement to verify
        :return: Verification result with confidence
        """
        response = self.query(claim, full=True)

        if not response["success"]:
            return {
                "verified": False,
                "confidence": 0,
                "reason": "API request failed"
            }

        # Analyze pods for verification
        verification_data = []
        for pod in response["data"]:
            if "result" in pod["title"].lower():
                verification_data.extend(subpod["text"] for subpod in pod["subpods"])

        if verification_data:
            return {
                "verified": True,
                "confidence": min(90, len(verification_data) * 30),
                "sources": verification_data
            }
        else:
            return {
                "verified": False,
                "confidence": 10,
                "reason": "No direct confirmation found"
            }


# Example integration with your fact verification system
if __name__ == "__main__":
    # Initialize with your app ID
    wolfram = WolframExpert("XR8UQ7YQPA")

    # 1. Test simple cacheable query
    print("Simple query (cached):", wolfram.query("2+2")["data"])

    # 2. Test full structured query
    eiffel_data = wolfram.query("Eiffel Tower height", full=True)
    print("\nEiffel Tower height verification:")
    print(json.dumps(eiffel_data, indent=2))

    # 3. Fact verification example
    verification = wolfram.verify_fact("The Eiffel Tower is 330 meters tall")
    print("\nFact verification result:")
    print(json.dumps(verification, indent=2))

    # 4. Show cache status
    print("\nCache stats:")
    cursor = wolfram.conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM cache")
    print(f"Cached queries: {cursor.fetchone()[0]}")