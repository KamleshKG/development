import spacy
import wikipedia
import wolframalpha
import sqlite3
import os
from dotenv import load_dotenv

load_dotenv()

# Initialize APIs
nlp = spacy.load("en_core_web_lg")
wolfram_client = wolframalpha.Client(os.getenv("WOLFRAM_API_KEY"))

def get_local_db_connection():
    return sqlite3.connect("knowledge/local_db/facts.db")

def detect_claims(text):
    """Extract factual claims using NLP"""
    doc = nlp(text)
    claims = [ent.text for ent in doc.ents if ent.label_ in ["DATE", "GPE", "ORG"]]
    return claims


def validate_claim(claim):
    """Debug version to show live API calls"""
    print(f"\n🔍 Validating claim: '{claim}'")

    # 1. Check Local DB
    conn = get_local_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM facts WHERE claim=?", (claim,))
    if cursor.fetchone():
        print("✅ Verified by Local DB")
        conn.close()
        return True
    conn.close()

    # 2. Check Wikipedia
    try:
        wiki_result = wikipedia.search(claim)[:1]
        if wiki_result:
            print(f"🌐 Wikipedia Match: {wiki_result[0]}")
            return True
    except Exception as e:
        print(f"⚠️ Wikipedia Error: {str(e)}")

    # 3. Check Wolfram Alpha
    try:
        wolfram_result = next(iter(wolfram_client.query(claim).results))
        if wolfram_result:
            print(f"🧮 Wolfram Match: {wolfram_result.text}")
        return True
    except Exception as e:
        print(f"⚠️ Wolfram Error: {str(e)}")

    print("❌ No verification found")
    return False

def verify_llm_output(llm_text):
    """End-to-end verification"""
    claims = detect_claims(llm_text)
    verified = [claim for claim in claims if validate_claim(claim)]
    return {
        "input": llm_text,
        "verified_claims": verified,
        "unverified_claims": list(set(claims) - set(verified))
    }

if __name__ == "__main__":
    test_input = "The Eiffel Tower is in London and was built in 1995."
    print(verify_llm_output(test_input))