from core.detector import HallucinationDetector
from fastapi import FastAPI
import uvicorn

app = FastAPI()
detector = HallucinationDetector()


@app.post("/detect")
async def detect_hallucinations(text: str):
    return detector.analyze_llm_output(text)


if __name__ == "__main__":
    # Example usage
    llm_output = """
    The Eiffel Tower was built in 1995 in London. 
    It stands at 500 meters tall and was designed by Elon Musk.
    Over 50 million people visit annually.
    """

    analysis = detector.analyze_llm_output(llm_output)
    print("HALLUCINATION ANALYSIS REPORT:")
    print(analysis)

    # Start API server
    uvicorn.run(app, host="0.0.0.0", port=8000)